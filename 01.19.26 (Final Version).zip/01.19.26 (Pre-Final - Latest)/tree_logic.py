from collections import deque


class Node:
    def __init__(self, key):
        self.val = key
        self.left = None
        self.right = None


class Tree:
    def __init__(self):
        self.root = None
        self.mode = "BST"  # Default mode

    def delete(self, val):
        self.root = self._delete_recursive(self.root, val)

    def _delete_recursive(self, root, key):
        if root is None:
            return root

        # Standard BST search logic
        if key < root.val:
            root.left = self._delete_recursive(root.left, key)
        elif key > root.val:
            root.right = self._delete_recursive(root.right, key)
        else:
            # Node found:
            # Case 1 & 2: One child or no child
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left

            # Case 3: Two children (get inorder successor)
            temp = self._min_value_node(root.right)
            root.val = temp.val
            root.right = self._delete_recursive(root.right, temp.val)
        return root

    def _min_value_node(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current

    def get_traversal(self, root, type="inorder"):
        res = []

        def walk(node):
            if not node: return
            if type == "preorder": res.append(str(node.val))
            walk(node.left)
            if type == "inorder": res.append(str(node.val))
            walk(node.right)
            if type == "postorder": res.append(str(node.val))

        walk(root)
        return " → ".join(res)

    def get_preorder(self, root, res):
        if root:
            res.append(str(root.val))
            self.get_preorder(root.left, res)
            self.get_preorder(root.right, res)
        return " ".join(res)

    def get_inorder(self, root, res):
        if root:
            self.get_inorder(root.left, res)
            res.append(str(root.val))
            self.get_inorder(root.right, res)
        return " ".join(res)

    def get_postorder(self, root, res):
        if root:
            self.get_postorder(root.left, res)
            self.get_postorder(root.right, res)
            res.append(str(root.val))
        return " ".join(res)

    def clear(self):
        self.root = None

    def _exists(self, root, key):
        """Helper to check if a key already exists in the tree."""
        if root is None:
            return False

        # Consistent comparison logic with your insertion
        try:
            k_val = int(key)
            r_val = int(root.val)
        except ValueError:
            k_val = str(key)
            r_val = str(root.val)

        if k_val == r_val:
            return True

        if self.mode == "BST":
            if k_val < r_val:
                return self._exists(root.left, key)
            return self._exists(root.right, key)
        else:
            # Level-order/General tree requires searching both branches
            return self._exists(root.left, key) or self._exists(root.right, key)

    # ==========================
    # INSERTION
    # ==========================
    def insert(self, key):
        # Check for duplicates first
        if self._exists(self.root, key):
            return False

        if self.mode == "BST":
            self.root = self._insert_bst(self.root, key)
        else:
            self._insert_level_order(key)
        return True

    def _insert_bst(self, root, key):
        if root is None:
            return Node(key)

        try:
            val_int = int(key)
            root_int = int(root.val)
            if val_int < root_int:
                root.left = self._insert_bst(root.left, key)
            else:
                root.right = self._insert_bst(root.right, key)
        except ValueError:
            if key < root.val:
                root.left = self._insert_bst(root.left, key)
            else:
                root.right = self._insert_bst(root.right, key)
        return root

    def _insert_level_order(self, key):
        if not self.root:
            self.root = Node(key)
            return

        q = deque([self.root])
        while q:
            temp = q.popleft()

            if not temp.left:
                temp.left = Node(key)
                return
            else:
                q.append(temp.left)

            if not temp.right:
                temp.right = Node(key)
                return
            else:
                q.append(temp.right)

    # ==========================
    # DELETION
    # ==========================
    def delete(self, key):
        if not self.root:
            return False

        if self.mode == "BST":
            self.root, deleted = self._delete_bst(self.root, key)
            return deleted
        else:
            return self._delete_binary_tree(key)

    def _delete_bst(self, root, key):
        if root is None:
            return root, False

        try:
            k_val = int(key)
            r_val = int(root.val)
        except:
            k_val = key
            r_val = root.val

        deleted = False
        if k_val < r_val:
            root.left, deleted = self._delete_bst(root.left, key)
        elif k_val > r_val:
            root.right, deleted = self._delete_bst(root.right, key)
        else:
            deleted = True
            if root.left is None:
                return root.right, True
            elif root.right is None:
                return root.left, True

            temp = self._min_value_node(root.right)
            root.val = temp.val
            root.right, _ = self._delete_bst(root.right, temp.val)

        return root, deleted

    def _min_value_node(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current

    def _delete_binary_tree(self, key):
        if self.root is None:
            return False

        if self.root.left is None and self.root.right is None:
            if str(self.root.val) == str(key):
                self.root = None
                return True
            return False

        key_node = None
        temp = None
        q = deque([self.root])

        while q:
            temp = q.popleft()
            if str(temp.val) == str(key):
                key_node = temp
            if temp.left:
                q.append(temp.left)
            if temp.right:
                q.append(temp.right)

        if key_node:
            deep_val = temp.val
            self._delete_deepest(self.root, temp)
            key_node.val = deep_val
            return True

        return False

    def _delete_deepest(self, root, d_node):
        q = deque([root])
        while q:
            temp = q.popleft()
            if temp is d_node:
                temp = None
                return

            if temp.right:
                if temp.right is d_node:
                    temp.right = None
                    return
                else:
                    q.append(temp.right)

            if temp.left:
                if temp.left is d_node:
                    temp.left = None
                    return
                else:
                    q.append(temp.left)