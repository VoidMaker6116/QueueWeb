// VisuAlgo-style Sorting Algorithm Visualizations with Step-by-Step Animations

class SortingVisualizer {
    constructor(containerId, algorithm, statusElementId = null) {
        this.container = document.getElementById(containerId);
        this.algorithm = algorithm;
        this.bars = [];
        // Unique animation speeds per algorithm for distinct feel
        this.animationSpeed = {
            'bubble': 350,
            'selection': 400,
            'insertion': 300,
            'quick': 450,
            'merge': 500
        }[algorithm] || 400;
        this.statusElement = statusElementId ? document.getElementById(statusElementId) : null;
    }

    updateStatus(message) {
        if (this.statusElement) {
            this.statusElement.textContent = message;
        }
    }

    createBars(values) {
        this.container.innerHTML = '';
        this.bars = [];
        // Add algorithm-specific class for unique styling
        this.container.className = `python-visual-container ${this.algorithm}-visual`;
        values.forEach((val, index) => {
            const bar = document.createElement('div');
            bar.className = `python-bar ${this.algorithm}-bar`;
            bar.style.height = `${Math.min(val * 15, 170)}px`;
            bar.style.minHeight = '20px';
            bar.dataset.value = val;
            bar.dataset.index = index;
            
            const label = document.createElement('span');
            label.className = 'bar-label';
            label.textContent = val;
            bar.appendChild(label);
            
            this.container.appendChild(bar);
            this.bars.push(bar);
        });
    }

    clearAllHighlights() {
        this.bars.forEach(bar => {
            bar.classList.remove('comparing', 'swapping', 'min-candidate', 'key-element', 'sorted', 'current');
        });
    }

    async highlightBar(index, className, message = null) {
        const bar = this.bars[index];
        if (!bar) return;
        
        if (message) this.updateStatus(message);
        
        bar.classList.add(className);
        await this.sleep(this.animationSpeed);
        return bar;
    }

    async removeHighlight(index, className) {
        const bar = this.bars[index];
        if (!bar) return;
        bar.classList.remove(className);
    }

    async swapBars(index1, index2, message = null) {
        const bar1 = this.bars[index1];
        const bar2 = this.bars[index2];
        
        if (!bar1 || !bar2) return;

        if (message) this.updateStatus(message);

        // Clear other highlights
        this.clearAllHighlights();
        
        // Algorithm-specific swap animations
        const swapStyle = {
            'bubble': { lift: 50, duration: 0.5, curve: 'cubic-bezier(0.68, -0.55, 0.265, 1.55)' }, // Bouncy
            'selection': { lift: 60, duration: 0.6, curve: 'cubic-bezier(0.4, 0, 0.2, 1)' }, // Smooth
            'insertion': { lift: 35, duration: 0.4, curve: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)' }, // Quick
            'quick': { lift: 70, duration: 0.7, curve: 'cubic-bezier(0.34, 1.56, 0.64, 1)' }, // Energetic
            'merge': { lift: 55, duration: 0.6, curve: 'cubic-bezier(0.4, 0, 0.2, 1)' } // Smooth merge
        }[this.algorithm] || { lift: 40, duration: 0.6, curve: 'cubic-bezier(0.4, 0, 0.2, 1)' };
        
        // Add swap animation class
        bar1.classList.add('swapping');
        bar2.classList.add('swapping');

        // Store original positions
        const rect1 = bar1.getBoundingClientRect();
        const rect2 = bar2.getBoundingClientRect();
        const deltaX = rect2.left - rect1.left;

        // Animate the swap
        const tempHeight = bar1.style.height;
        const tempValue = bar1.dataset.value;
        const tempLabel = bar1.querySelector('.bar-label').textContent;

        // Algorithm-specific transition
        bar1.style.transition = `transform ${swapStyle.duration}s ${swapStyle.curve}, height ${swapStyle.duration}s ease`;
        bar2.style.transition = `transform ${swapStyle.duration}s ${swapStyle.curve}, height ${swapStyle.duration}s ease`;

        // Move bars up and swap positions with algorithm-specific lift
        bar1.style.transform = `translateY(-${swapStyle.lift}px) translateX(${deltaX}px) rotate(${this.algorithm === 'bubble' ? '5deg' : '0deg'})`;
        bar2.style.transform = `translateY(-${swapStyle.lift}px) translateX(${-deltaX}px) rotate(${this.algorithm === 'bubble' ? '-5deg' : '0deg'})`;

        await this.sleep(swapStyle.duration * 500);

        // Swap heights and values
        bar1.style.height = bar2.style.height;
        bar2.style.height = tempHeight;
        bar1.dataset.value = bar2.dataset.value;
        bar2.dataset.value = tempValue;
        bar1.querySelector('.bar-label').textContent = bar2.querySelector('.bar-label').textContent;
        bar2.querySelector('.bar-label').textContent = tempLabel;
        
        // For merge sort, rebuild bars array after swap to keep in sync
        if (this.algorithm === 'merge') {
            this.rebuildBarsArray();
        }

        await this.sleep(swapStyle.duration * 300);

        // Move bars back down to original positions
        bar1.style.transform = 'translateY(0) translateX(0) rotate(0deg)';
        bar2.style.transform = 'translateY(0) translateX(0) rotate(0deg)';

        await this.sleep(swapStyle.duration * 300);

        // Remove swap class
        bar1.classList.remove('swapping');
        bar2.classList.remove('swapping');
        
        // Reset transitions
        bar1.style.transition = '';
        bar2.style.transition = '';
    }

    async markSorted(index, message = null) {
        const bar = this.bars[index];
        if (!bar) return;
        
        if (message) this.updateStatus(message);
        
        bar.classList.add('sorted');
        bar.style.transition = 'background-color 0.4s ease, border-color 0.4s ease';
        await this.sleep(200);
    }

    async markComparing(index1, index2, message = null) {
        if (message) this.updateStatus(message);
        
        await this.highlightBar(index1, 'comparing', null);
        await this.highlightBar(index2, 'comparing', null);
        await this.sleep(100);
    }

    async removeComparing(index1, index2) {
        await this.removeHighlight(index1, 'comparing');
        await this.removeHighlight(index2, 'comparing');
    }

    rebuildBarsArray() {
        // Rebuild bars array from DOM to keep in sync with current elements
        this.bars = Array.from(this.container.querySelectorAll('.python-bar'));
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Bubble Sort Animation - VisuAlgo Style
async function animateBubbleSort(values) {
    const statusId = 'bubble-status-text';
    // Create status element if it doesn't exist
    let statusEl = document.getElementById(statusId);
    if (!statusEl) {
        statusEl = document.createElement('div');
        statusEl.id = statusId;
        statusEl.className = 'sort-status-text';
        const container = document.getElementById('bubble-visual-container');
        if (container && container.parentElement) {
            container.parentElement.insertBefore(statusEl, container);
        }
    }
    
    const visualizer = new SortingVisualizer('bubble-visual-container', 'bubble', statusId);
    visualizer.createBars(values);
    visualizer.updateStatus('Starting Bubble Sort...');
    await visualizer.sleep(500);
    
    const arr = [...values];
    const n = arr.length;
    
    for (let i = 0; i < n; i++) {
        let swapped = false;
        visualizer.updateStatus(`Pass ${i + 1}: Comparing adjacent elements...`);
        await visualizer.sleep(300);
        
        for (let j = 0; j < n - i - 1; j++) {
            // Highlight comparing bars
            await visualizer.markComparing(
                j, 
                j + 1, 
                `Comparing ${arr[j]} and ${arr[j + 1]}...`
            );
            
            if (arr[j] > arr[j + 1]) {
                // Swap
                [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
                await visualizer.swapBars(
                    j, 
                    j + 1, 
                    `Swapping ${arr[j + 1]} and ${arr[j]} (${arr[j + 1]} > ${arr[j]})`
                );
                swapped = true;
            } else {
                await visualizer.updateStatus(`${arr[j]} ≤ ${arr[j + 1]}, no swap needed`);
                await visualizer.sleep(300);
            }
            
            // Remove highlight
            await visualizer.removeComparing(j, j + 1);
        }
        
        // Mark last element as sorted (bubble up effect)
        await visualizer.markSorted(
            n - i - 1, 
            `Element ${arr[n - i - 1]} is now in its final position`
        );
        
        if (!swapped) {
            visualizer.updateStatus('No swaps occurred. Array is sorted!');
            await visualizer.sleep(500);
            // Mark remaining as sorted
            for (let k = 0; k < n - i - 1; k++) {
                await visualizer.markSorted(k, null);
            }
            break;
        }
    }
    
    visualizer.updateStatus('Bubble Sort Complete!');
}

// Selection Sort Animation - VisuAlgo Style
async function animateSelectionSort(values) {
    const statusId = 'selection-status-text';
    let statusEl = document.getElementById(statusId);
    if (!statusEl) {
        statusEl = document.createElement('div');
        statusEl.id = statusId;
        statusEl.className = 'sort-status-text';
        const container = document.getElementById('selection-visual-container');
        if (container && container.parentElement) {
            container.parentElement.insertBefore(statusEl, container);
        }
    }
    
    const visualizer = new SortingVisualizer('selection-visual-container', 'selection', statusId);
    visualizer.createBars(values);
    visualizer.updateStatus('Starting Selection Sort...');
    await visualizer.sleep(500);
    
    const arr = [...values];
    const n = arr.length;
    
    for (let i = 0; i < n; i++) {
        let minIndex = i;
        
        visualizer.updateStatus(`Iteration ${i + 1}: Finding minimum in unsorted portion...`);
        await visualizer.sleep(300);
        
        // Mark current minimum candidate
        await visualizer.highlightBar(
            i, 
            'min-candidate', 
            `Current minimum candidate: ${arr[i]} at position ${i}`
        );
        
        // Find minimum
        for (let j = i + 1; j < n; j++) {
            await visualizer.highlightBar(
                j, 
                'comparing', 
                `Comparing ${arr[j]} with current minimum ${arr[minIndex]}...`
            );
            await visualizer.sleep(visualizer.animationSpeed);
            
            if (arr[j] < arr[minIndex]) {
                if (minIndex !== i) {
                    await visualizer.removeHighlight(minIndex, 'min-candidate');
                }
                minIndex = j;
                await visualizer.highlightBar(
                    minIndex, 
                    'min-candidate', 
                    `New minimum found: ${arr[minIndex]} at position ${minIndex}`
                );
            } else {
                visualizer.updateStatus(`${arr[j]} ≥ ${arr[minIndex]}, keeping current minimum`);
                await visualizer.sleep(200);
            }
            
            await visualizer.removeHighlight(j, 'comparing');
        }
        
        // Swap if needed
        if (minIndex !== i) {
            [arr[i], arr[minIndex]] = [arr[minIndex], arr[i]];
            await visualizer.swapBars(
                i, 
                minIndex, 
                `Swapping ${arr[i]} (minimum) to position ${i}`
            );
            await visualizer.removeHighlight(minIndex, 'min-candidate');
        } else {
            visualizer.updateStatus(`Element ${arr[i]} is already in correct position`);
            await visualizer.sleep(300);
            await visualizer.removeHighlight(i, 'min-candidate');
        }
        
        // Mark as sorted
        await visualizer.markSorted(
            i, 
            `Position ${i} is now sorted with value ${arr[i]}`
        );
    }
    
    visualizer.updateStatus('Selection Sort Complete!');
}

// Insertion Sort Animation - VisuAlgo Style
async function animateInsertionSort(values) {
    const statusId = 'insertion-status-text';
    let statusEl = document.getElementById(statusId);
    if (!statusEl) {
        statusEl = document.createElement('div');
        statusEl.id = statusId;
        statusEl.className = 'sort-status-text';
        const container = document.getElementById('insertion-visual-container');
        if (container && container.parentElement) {
            container.parentElement.insertBefore(statusEl, container);
        }
    }
    
    const visualizer = new SortingVisualizer('insertion-visual-container', 'insertion', statusId);
    visualizer.createBars(values);
    visualizer.updateStatus('Starting Insertion Sort...');
    await visualizer.sleep(500);
    
    // Mark first element as sorted
    await visualizer.markSorted(0, 'First element is already sorted');
    
    const arr = [...values];
    const n = arr.length;
    
    for (let i = 1; i < n; i++) {
        const key = arr[i];
        let j = i - 1;
        
        visualizer.updateStatus(`Inserting ${key} into sorted portion...`);
        await visualizer.sleep(300);
        
        // Highlight key element
        await visualizer.highlightBar(
            i, 
            'key-element', 
            `Key element: ${key} to be inserted`
        );
        await visualizer.sleep(visualizer.animationSpeed);
        
        // Move elements to the right
        while (j >= 0 && arr[j] > key) {
            await visualizer.highlightBar(
                j, 
                'comparing', 
                `Comparing ${arr[j]} with key ${key}...`
            );
            await visualizer.sleep(visualizer.animationSpeed);
            
            visualizer.updateStatus(`${arr[j]} > ${key}, shifting ${arr[j]} to the right`);
            arr[j + 1] = arr[j];
            
            // Visual shift - animate the bar moving
            const barJ = visualizer.bars[j];
            const barJPlus1 = visualizer.bars[j + 1];
            if (barJ && barJPlus1) {
                barJPlus1.style.height = barJ.style.height;
                barJPlus1.querySelector('.bar-label').textContent = arr[j];
                barJPlus1.dataset.value = arr[j];
                barJPlus1.classList.add('comparing');
                await visualizer.sleep(300);
                barJPlus1.classList.remove('comparing');
            }
            
            await visualizer.removeHighlight(j, 'comparing');
            j--;
        }
        
        // Insert key at correct position
        arr[j + 1] = key;
        const finalBar = visualizer.bars[j + 1];
        if (finalBar) {
            finalBar.style.height = `${Math.min(key * 15, 170)}px`;
            finalBar.querySelector('.bar-label').textContent = key;
            finalBar.dataset.value = key;
            finalBar.classList.add('key-element');
            await visualizer.sleep(200);
        }
        
        visualizer.updateStatus(`Inserted ${key} at position ${j + 1}`);
        await visualizer.sleep(300);
        
        await visualizer.removeHighlight(i, 'key-element');
        if (finalBar) finalBar.classList.remove('key-element');
        await visualizer.markSorted(j + 1, null);
    }
    
    visualizer.updateStatus('Insertion Sort Complete!');
}

// Merge Sort Animation - VisuAlgo Style (JavaScript-based)
async function animateMergeSort(values) {
    const statusId = 'merge-status-text';
    let statusEl = document.getElementById(statusId);
    if (!statusEl) {
        statusEl = document.createElement('div');
        statusEl.id = statusId;
        statusEl.className = 'sort-status-text';
        const container = document.getElementById('merge-visual-container');
        if (container && container.parentElement) {
            container.parentElement.insertBefore(statusEl, container);
        }
    }
    
    // Show container first
    const container = document.getElementById('merge-visual-container');
    if (container) {
        container.style.display = 'flex';
    }
    if (statusEl) {
        statusEl.style.display = 'flex';
    }
    
    const visualizer = new SortingVisualizer('merge-visual-container', 'merge', statusId);
    visualizer.createBars(values);
    visualizer.updateStatus('Starting Merge Sort...');
    await visualizer.sleep(500);
    
    const arr = [...values];
    const n = arr.length;
    
    // Merge sort with step-by-step visualization
    await mergeSortRecursive(arr, visualizer, 0, n - 1);
    
    // Mark all as sorted
    visualizer.clearAllHighlights();
    for (let i = 0; i < n; i++) {
        if (visualizer.bars[i]) {
            visualizer.bars[i].classList.add('sorted');
        }
        await visualizer.sleep(100);
    }
    
    visualizer.updateStatus('Merge Sort Complete!');
}

async function mergeSortRecursive(arr, visualizer, left, right) {
    if (left < right) {
        const mid = Math.floor((left + right) / 2);
        
        visualizer.updateStatus(`Divide: Splitting array from index ${left} to ${right} at midpoint ${mid}`);
        await visualizer.sleep(visualizer.animationSpeed);
        
        // Highlight the range being divided (VisuAlgo style)
        visualizer.clearAllHighlights();
        for (let i = left; i <= right; i++) {
            if (visualizer.bars[i]) {
                visualizer.bars[i].classList.add('comparing');
            }
        }
        await visualizer.sleep(400);
        
        // Clear highlights before recursion
        for (let i = left; i <= right; i++) {
            if (visualizer.bars[i]) {
                visualizer.bars[i].classList.remove('comparing');
            }
        }
        
        // Recursively sort left and right halves
        await mergeSortRecursive(arr, visualizer, left, mid);
        await mergeSortRecursive(arr, visualizer, mid + 1, right);
        
        // Merge the sorted halves
        await merge(arr, visualizer, left, mid, right);
    } else if (left === right) {
        // Single element is already sorted
        visualizer.updateStatus(`Base case: Single element ${arr[left]} at position ${left} is sorted`);
        await visualizer.markSorted(left, null);
    }
}

async function merge(arr, visualizer, left, mid, right) {
    const n1 = mid - left + 1;
    const n2 = right - mid;
    const L = [];
    const R = [];
    
    // Copy data to temporary arrays
    for (let i = 0; i < n1; i++) {
        L[i] = arr[left + i];
    }
    for (let j = 0; j < n2; j++) {
        R[j] = arr[mid + 1 + j];
    }
    
    visualizer.updateStatus(`Merge: Combining two sorted segments [${left}-${mid}] and [${mid+1}-${right}]`);
    await visualizer.sleep(visualizer.animationSpeed);
    
    // Clear all highlights first
    visualizer.clearAllHighlights();
    
    // Highlight left segment (VisuAlgo style - one color for left)
    for (let i = left; i <= mid; i++) {
        if (visualizer.bars[i]) {
            visualizer.bars[i].classList.add('min-candidate');
        }
    }
    await visualizer.sleep(300);
    
    // Highlight right segment (different color for right)
    for (let i = mid + 1; i <= right; i++) {
        if (visualizer.bars[i]) {
            visualizer.bars[i].classList.add('comparing');
        }
    }
    await visualizer.sleep(400);
    
    let i = 0, j = 0, k = left;
    
    // Merge the two arrays
    while (i < n1 && j < n2) {
        const leftIdx = left + i;
        const rightIdx = mid + 1 + j;
        
        visualizer.updateStatus(`Merge Compare: ${L[i]} (left) vs ${R[j]} (right)`);
        
        // Highlight comparing elements (VisuAlgo style - left vs right)
        if (visualizer.bars[leftIdx]) {
            visualizer.bars[leftIdx].classList.remove('min-candidate');
            visualizer.bars[leftIdx].classList.add('key-element');
        }
        if (visualizer.bars[rightIdx]) {
            visualizer.bars[rightIdx].classList.remove('comparing');
            visualizer.bars[rightIdx].classList.add('comparing');
        }
        await visualizer.sleep(visualizer.animationSpeed);
        
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            visualizer.updateStatus(`Merge Place: ${L[i]} ≤ ${R[j]}, placing ${L[i]} at position ${k}`);
            
            // Get current bars (rebuild array to stay in sync)
            visualizer.rebuildBarsArray();
            const barAtK = visualizer.bars[k];
            const barAtLeft = visualizer.bars[leftIdx];
            
            if (barAtK && barAtLeft && leftIdx !== k) {
                // Need to move element from leftIdx to k
                await visualizer.swapBars(leftIdx, k, null);
                visualizer.rebuildBarsArray(); // Rebuild after swap
            } else if (barAtK) {
                // Already in correct position, just update value
                barAtK.style.height = `${Math.min(L[i] * 15, 170)}px`;
                barAtK.querySelector('.bar-label').textContent = L[i];
                barAtK.dataset.value = L[i];
            }
            
            if (visualizer.bars[leftIdx]) {
                visualizer.bars[leftIdx].classList.remove('key-element');
            }
            i++;
        } else {
            arr[k] = R[j];
            visualizer.updateStatus(`Merge Place: ${R[j]} < ${L[i]}, placing ${R[j]} at position ${k}`);
            
            // Get current bars (rebuild array to stay in sync)
            visualizer.rebuildBarsArray();
            const barAtK = visualizer.bars[k];
            const barAtRight = visualizer.bars[rightIdx];
            
            if (barAtK && barAtRight && rightIdx !== k) {
                // Need to move element from rightIdx to k
                await visualizer.swapBars(rightIdx, k, null);
                visualizer.rebuildBarsArray(); // Rebuild after swap
            } else if (barAtK) {
                // Already in correct position, just update value
                barAtK.style.height = `${Math.min(R[j] * 15, 170)}px`;
                barAtK.querySelector('.bar-label').textContent = R[j];
                barAtK.dataset.value = R[j];
            }
            
            if (visualizer.bars[rightIdx]) {
                visualizer.bars[rightIdx].classList.remove('comparing');
            }
            j++;
        }
        
        if (visualizer.bars[k]) {
            visualizer.bars[k].classList.add('sorted');
        }
        k++;
    }
    
    // Copy remaining elements of L[]
    while (i < n1) {
        arr[k] = L[i];
        const leftIdx = left + i;
        visualizer.updateStatus(`Placing remaining ${L[i]} from left segment at position ${k}`);
        
        visualizer.rebuildBarsArray();
        const barAtK = visualizer.bars[k];
        const barAtLeft = visualizer.bars[leftIdx];
        
        if (barAtK && barAtLeft && leftIdx !== k) {
            await visualizer.swapBars(leftIdx, k, null);
            visualizer.rebuildBarsArray();
        } else if (barAtK) {
            barAtK.style.height = `${Math.min(L[i] * 15, 170)}px`;
            barAtK.querySelector('.bar-label').textContent = L[i];
            barAtK.dataset.value = L[i];
        }
        
        if (visualizer.bars[leftIdx]) {
            visualizer.bars[leftIdx].classList.remove('min-candidate');
        }
        if (visualizer.bars[k]) {
            visualizer.bars[k].classList.add('sorted');
        }
        i++;
        k++;
    }
    
    // Copy remaining elements of R[]
    while (j < n2) {
        arr[k] = R[j];
        const rightIdx = mid + 1 + j;
        visualizer.updateStatus(`Placing remaining ${R[j]} from right segment at position ${k}`);
        
        visualizer.rebuildBarsArray();
        const barAtK = visualizer.bars[k];
        const barAtRight = visualizer.bars[rightIdx];
        
        if (barAtK && barAtRight && rightIdx !== k) {
            await visualizer.swapBars(rightIdx, k, null);
            visualizer.rebuildBarsArray();
        } else if (barAtK) {
            barAtK.style.height = `${Math.min(R[j] * 15, 170)}px`;
            barAtK.querySelector('.bar-label').textContent = R[j];
            barAtK.dataset.value = R[j];
        }
        
        if (visualizer.bars[rightIdx]) {
            visualizer.bars[rightIdx].classList.remove('comparing');
        }
        if (visualizer.bars[k]) {
            visualizer.bars[k].classList.add('sorted');
        }
        j++;
        k++;
    }
    
    // Clear all highlights
    visualizer.clearAllHighlights();
}

// Export functions and class
window.animateBubbleSort = animateBubbleSort;
window.animateSelectionSort = animateSelectionSort;
window.animateInsertionSort = animateInsertionSort;
window.animateMergeSort = animateMergeSort;
window.SortingVisualizer = SortingVisualizer;
