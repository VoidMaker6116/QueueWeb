from collections import deque
from flask import Flask, render_template, request   

app = Flask(__name__)

class Graph:
    def __init__(self):
        self.graph = {}

    def add_station(self, station):
        if station not in self.graph:
            self.graph[station] = []

    def add_connection(self, station1, station2):
        self.graph[station1].append(station2)
        self.graph[station2].append(station1)

    def bfs_shortest_path(self, start, goal):
        # Return None early if either station doesn't exist
        if start not in self.graph or goal not in self.graph:
            return None

        # If start equals goal, return immediately
        if start == goal:
            return [start]

        queue = deque([[start]])
        visited = set()

        while queue:
            path = queue.popleft()
            node = path[-1]

            if node == goal:
                return path
            
            if node not in visited:
                visited.add(node)
                
                for neighbor in self.graph[node]:
                    new_path = list(path)
                    new_path.append(neighbor)
                    queue.append(new_path)

        return None
    
mrt_graph = Graph()
           
# LRT1 Stations (Green Line) - from Baclaran to Monumento
lrt1_stations = [
        "Dr. Arcadio Santos", "Ninoy Aquino Avenue", "Asia World/PITX", "MIA Road", "Redemptorist-Aseana", 
        "Baclaran", "EDSA", "Libertad", "Gil Puyat", "Vito Cruz", 
        "Quirino", "Pedro Gil", "United Nations", "Central Terminal", "Carriedo", 
        "Doroteo Jose", "Bambang", "Tayuman", "Blumentritt", "Abad Santos", 
        "R. Papa", "5th Avenue", "Yamaha Monumento", "Balintawak", "Fernando Poe Jr."
    ]

# LRT2 Stations (Purple Line) - from Recto to Santolan
lrt2_stations = [
        "Recto", "Legarda", "Pureza", "V. Mapa", "J. Ruiz",  "Gilmore", "Betty Go-Belmonte", 
        "Araneta Center-Cubao", "Anonas", "Katipunan", "Santolan", "Marikina-Pasig", "Antipolo"
    ]

# MRT3 Stations (Yellow Line) - North Ave to Taft
mrt3_stations = [
        "North Avenue", "Quezon Avenue", "GMA-Kamuning", "Araneta Center-Cubao", "Santolan-Annapolis", 
        "Ortigas", "Shaw Boulevard", "Boni", "Guadalupe", "Buendia", "Ayala", "Magallanes", "Taft Avenue"
    ]

# Add all stations
all_stations = lrt1_stations + lrt2_stations + mrt3_stations
for station in set(all_stations):
    mrt_graph.add_station(station)

# LRT1 Connections (Green Line)
lrt1_connections = [
    ("Dr. Arcadio Santos", "Ninoy Aquino Avenue"),
    ("Ninoy Aquino Avenue", "Asia World/PITX"),
    ("Asia World/PITX", "MIA Road"),
    ("MIA Road", "Redemptorist-Aseana"),
    ("Redemptorist-Aseana", "Baclaran"),
    ("Baclaran", "EDSA"),
    ("EDSA", "Libertad"),
    ("Libertad", "Gil Puyat"),
    ("Gil Puyat", "Vito Cruz"),
    ("Vito Cruz", "Quirino"),
    ("Quirino", "Pedro Gil"),
    ("Pedro Gil", "United Nations"),
    ("United Nations", "Central Terminal"),
    ("Central Terminal", "Carriedo"),
    ("Carriedo", "Doroteo Jose"),
    ("Doroteo Jose", "Bambang"),
    ("Bambang", "Tayuman"),
    ("Tayuman", "Blumentritt"),
    ("Blumentritt", "Abad Santos"),
    ("Abad Santos", "R. Papa"),
    ("R. Papa", "5th Avenue"),
    ("5th Avenue", "Yamaha Monumento"),
    ("Yamaha Monumento", "Balintawak"),
    ("Balintawak", "Fernando Poe Jr.")
]

# LRT2 Connections (Purple Line)
lrt2_connections = [
    ("Recto", "Legarda"),
    ("Legarda", "Pureza"),
    ("Pureza", "V. Mapa"),
    ("V. Mapa", "J. Ruiz"),
    ("J. Ruiz", "Gilmore"),
    ("Gilmore", "Betty Go-Belmonte"),
    ("Betty Go-Belmonte", "Araneta Center-Cubao"),
    ("Araneta Center-Cubao", "Anonas"),
    ("Anonas", "Katipunan"),
    ("Katipunan", "Santolan"),
    ("Santolan", "Marikina-Pasig"),
    ("Marikina-Pasig", "Antipolo")
]

# MRT3 Connections (Yellow Line)
mrt3_connections = [
    ("North Avenue", "Quezon Avenue"),
    ("Quezon Avenue", "GMA-Kamuning"),
    ("GMA-Kamuning", "Araneta Center-Cubao"),
    ("Araneta Center-Cubao", "Santolan-Annapolis"),
    ("Santolan-Annapolis", "Ortigas"),
    ("Ortigas", "Shaw Boulevard"),
    ("Shaw Boulevard", "Boni"),
    ("Boni", "Guadalupe"),
    ("Guadalupe", "Buendia"),
    ("Buendia", "Ayala"),
    ("Ayala", "Magallanes"),
    ("Magallanes", "Taft Avenue")
]

#Transfer Connections
transfer_connections = [
    ("Doroteo Jose", "Recto"),
    ("EDSA", "Taft Avenue"),
    ("Araneta Center-Cubao", "Araneta Center-Cubao"),
]

# Add all connections
for s1, s2 in lrt1_connections + lrt2_connections + mrt3_connections:
    mrt_graph.add_connection(s1, s2)

for s1, s2 in transfer_connections:
    mrt_graph.add_connection(s1, s2)

@app.route('/mrt_bfs')
def stations():
    line_colors = {}
    for station in lrt1_stations:
        line_colors[station] = 'LRT1'
    for station in lrt2_stations:
        line_colors[station] = 'LRT2'
    for station in mrt3_stations:
        line_colors[station] = 'MRT3'