from winreg import DisableReflectionKey
from flask import Flask, render_template, request, redirect
from queue_ds import Queue
import os
from binary_tree import BinaryTree, Node
from graph import mrt_graph
from tree_logic import Tree
from quick_sort import quick_sort
from bubble_sort import bubble_sort
from selection_sort import selection_sort
import time
from insertion_sort import insertion_sort
import json
from flask import session, flash, url_for
from merge_sort_logic import get_merge_sort_history


app = Flask(
    __name__,
    template_folder=os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates"),
    static_folder=os.path.join(os.path.dirname(os.path.abspath(__file__)), "static"),
)

app.secret_key = "bruh" 

# instantiate queue as an object
queue = Queue()

# instantiate a binary tree for the site (keeps state while server runs)
# last_search holds last search result (True/False/None)
last_search = None
bt_instance = Tree()  # For the Binary Tree card
bst_instance = Tree() # For the Binary Search Tree card
bt_traversal_result = ""
bt_highlight_nodes = []
@app.route("/")
def index():
    return render_template(
        "index.html",
        queue=queue.get_all(),
        front=queue.peek(),
        bt_root=bt_instance.root,
        bst_root=bst_instance.root,
        bst_inorder=bst_instance.get_traversal(bst_instance.root, "inorder"),
        bt_traversal_output=bt_traversal_result, # Pass the result here
        bt_highlights=bt_highlight_nodes,  # Pass the list to the template
        current_year=2026
    )
# --- Binary Tree Routes ---
@app.route("/bt_traverse/<order>", methods=["POST"])
def bt_traverse(order):
    global bt_traversal_result, bt_highlight_nodes
    if bt_instance.root:
        # Get the string result from your logic
        result_str = bt_instance.get_traversal(bt_instance.root, order)
        bt_traversal_result = result_str
        # Turn "A B C " into ["A", "B", "C"] for highlighting
        bt_highlight_nodes = result_str.strip().split(" ")
    else:
        bt_traversal_result = "Tree is empty!"
        bt_highlight_nodes = []
    # Check if panel was open and preserve it
    panel_was_open = request.form.get('panel_open', 'false') == 'true'
    panel_page = request.form.get('panel_page', '0')
    if panel_was_open:
        return redirect(f"/?panel_open=true&panel_page={panel_page}#bt-section")
    return redirect("/#bt-section")


@app.route('/quicksort', methods=['GET', 'POST'])
def quicksort():
    results = None
    if request.method == 'POST':
        raw_input = request.form.get('numbers', '')
        try:
            data = [int(x.strip()) for x in raw_input.split(',') if x.strip()]
            start_time = time.perf_counter()
            sorted_data = quick_sort(list(data))
            duration = (time.perf_counter() - start_time) * 1000

            results = {
                "original": data,
                "sorted": sorted_data,
                "time_ms": round(duration, 4),
                "count": len(data)
            }
        except ValueError:
            results = {"error": "Invalid input. Please use numbers."}
    return render_template('quicksort.html', results=results, current_year=2026)

@app.route("/bt_insert", methods=["POST"])
def bt_insert():
    value = request.form.get("value", "").strip()
    if value:
        bt_instance.mode = "BT"  #
        bt_instance.insert(value)
    # Check if panel was open and preserve it
    panel_was_open = request.form.get('panel_open', 'false') == 'true'
    panel_page = request.form.get('panel_page', '0')
    if panel_was_open:
        return redirect(f"/?panel_open=true&panel_page={panel_page}#bt-section")
    return redirect("/#bt-section")

# FIXED: Added methods=["POST"] to match your HTML form
@app.route("/bt_clear", methods=["POST"])
def bt_clear():
    global bt_traversal_result, bt_highlight_nodes
    bt_instance.clear()
    bt_traversal_result = ""
    bt_highlight_nodes = [] # Reset highlights on clear
    # Check if panel was open and preserve it
    panel_was_open = request.form.get('panel_open', 'false') == 'true'
    panel_page = request.form.get('panel_page', '0')
    if panel_was_open:
        return redirect(f"/?panel_open=true&panel_page={panel_page}#bt-section")
    return redirect("/#bt-section")

# --- BST Routes ---
@app.route("/bst_insert", methods=["POST"])
def bst_insert():
    value = request.form.get("value", "").strip()
    if value:
        bst_instance.mode = "BST" #
        bst_instance.insert(value)
    # Check if panel was open and preserve it
    panel_was_open = request.form.get('panel_open', 'false') == 'true'
    panel_page = request.form.get('panel_page', '0')
    if panel_was_open:
        return redirect(f"/?panel_open=true&panel_page={panel_page}#bst-section")
    return redirect("/#bst-section")

@app.route("/bst_delete", methods=["POST"])
def bst_delete():
    value = request.form.get("value", "").strip()
    if value and bst_instance.root:
        bst_instance.mode = "BST"
        # Optional: convert to int if your tree nodes are numeric
        try:
            val_to_delete = int(value)
        except ValueError:
            val_to_delete = value

        bst_instance.delete(val_to_delete)
    # Check if panel was open and preserve it
    panel_was_open = request.form.get('panel_open', 'false') == 'true'
    panel_page = request.form.get('panel_page', '0')
    if panel_was_open:
        return redirect(f"/?panel_open=true&panel_page={panel_page}#bst-section")
    return redirect("/#bst-section")

# FIXED: Added methods=["POST"] to match your HTML form
@app.route("/bst_clear", methods=["POST"])
def bst_clear():
    bst_instance.clear()
    # Check if panel was open and preserve it
    panel_was_open = request.form.get('panel_open', 'false') == 'true'
    panel_page = request.form.get('panel_page', '0')
    if panel_was_open:
        return redirect(f"/?panel_open=true&panel_page={panel_page}#bst-section")
    return redirect("/#bst-section")
#Graph: Find shortest path (POST)
@app.route("/mrt_bfs", methods=["GET", "POST"])
def mrt_bfs():
    path = None
    searched = False
    start_raw = None
    end_raw = None
    start = None
    end = None

    if request.method == "POST":
        searched = True
        start_raw = (request.form.get("start") or "").strip()
        end_raw = (request.form.get("end") or "").strip()

        # Case-insensitive match to existing station names in mrt_graph
        def match_station(name):
            if not name:
                return None
            for s in mrt_graph.graph.keys():
                if s.lower() == name.lower():
                    return s
            return None

        start = match_station(start_raw)
        end = match_station(end_raw)

        if start and end:
            path = mrt_graph.bfs_shortest_path(start, end)
        else:
            path = None

    # pass the available station list to the template so we can use a datalist
    stations = list(mrt_graph.graph.keys())
    return render_template("mrt_bfs.html", path=path, searched=searched, start_raw=start_raw, end_raw=end_raw, stations=stations) 

# Sorting Algorithms Page
@app.route('/sortingalgos', methods=['GET', 'POST'])
def sortingalgos():
    results = None
    
    if request.method == 'POST' and 'algo_type' in request.form:
        raw_input = request.form.get('numbers', '')
        algo_type = request.form.get('algo_type', 'selection')

        try:
            data = [int(x.strip()) for x in raw_input.split(',') if x.strip()]
            start_time = time.perf_counter()

            if algo_type == 'bubble':
                sorted_data = bubble_sort(list(data))
                display_name = "Bubble"
            elif algo_type == 'selection':
                sorted_data = selection_sort(list(data))
                display_name = "Selection"
            elif algo_type == 'insertion':
                sorted_data = insertion_sort(list(data))
                display_name = "Insertion"

            duration = (time.perf_counter() - start_time) * 1000
            results = {
                "original": data,
                "sorted": sorted_data,
                "time_ms": round(duration, 4),
                "count": len(data),
                "algo_used": display_name
            }
        except ValueError:
            results = {"error": "Invalid input."}

    # --- MERGE SORT LOGIC ---
    animation_data = session.get('animation_data', None)
    merge_input_backup = session.get('merge_input_backup', '')
    
    if animation_data:
        session.pop('animation_data', None)

        session.modified = True

    return render_template(
        'sortingalgos.html', 
        results=results, 
        current_year=2026,
        animation_data=animation_data,
        merge_input_backup=merge_input_backup
    )

@app.route('/handle_merge_sort', methods=['POST'])
def handle_merge_sort():
    raw_input = request.form.get('raw_numbers', '')
    
    try:
        # 12 numbers only to avoid overflowing the animation
        data = [int(x.strip()) for x in raw_input.split(',') if x.strip()][:12]
        
        if not data:
            return redirect(url_for('sortingalgos') + "#merge-sort-card")

        sorted_arr, history = get_merge_sort_history(list(data))
        
        session['animation_data'] = json.dumps(history)
        session['merge_input_backup'] = raw_input
        session.modified = True

    except ValueError:
        pass
    
    return redirect(url_for('sortingalgos') + "#merge-sort-card")

# Members Page
@app.route("/members")
def members():
    return render_template("members.html")

if __name__ == "__main__":
    app.run(debug=True)