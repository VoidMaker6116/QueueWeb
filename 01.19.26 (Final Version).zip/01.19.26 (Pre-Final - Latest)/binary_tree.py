from collections import deque

class Node:
    """A node in a binary tree."""
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right


class BinaryTree:
    """A binary tree data structure."""
    def __init__(self, root_value=None):
        self.root = Node(root_value) if root_value is not None else None

    def insert_left(self, current_node, value):
        """Insert a node as the left child of the current node."""
        if current_node.left is None:
            current_node.left = Node(value)
        else:
            new_node = Node(value)
            new_node.left = current_node.left
            current_node.left = new_node

    def insert_right(self, current_node, value):
        """Insert a node as the right child of the current node."""
        if current_node.right is None:
            current_node.right = Node(value)
        else:
            new_node = Node(value)
            new_node.right = current_node.right
            current_node.right = new_node

    def preorder_traversal(self, start, traversal=""):
        """Traverse the tree in preorder (root, left, right)."""
        if start:
            traversal += str(start.value) + " "
            traversal = self.preorder_traversal(start.left, traversal)
            traversal = self.preorder_traversal(start.right, traversal)
        return traversal

    def inorder_traversal(self, start, traversal=""):
        """Traverse the tree in inorder (left, root, right)."""
        if start:
            traversal = self.inorder_traversal(start.left, traversal)
            traversal += str(start.value) + " "
            traversal = self.inorder_traversal(start.right, traversal)
        return traversal

    def post_traversal(self, start, traversal=""):
        """Traverse the tree in postorder (left, right, root)."""
        if start:
            traversal = self.post_traversal(start.left, traversal)
            traversal = self.post_traversal(start.right, traversal)
            traversal += str(start.value) + " "
        return traversal

    def search(self, root, key):
        """Search for a node with given key; returns the Node or None."""
        if root is None:
            return None
        if root.value == key:
            return root
        left_res = self.search(root.left, key)
        if left_res:
            return left_res
        return self.search(root.right, key)

    def delete_node(self, root, key):
        """Delete a node in a general binary tree."""
        if root is None:
            return None

        # If tree has only one node
        if root.left is None and root.right is None:
            if root.value == key:
                return None
            else:
                return root

        q = deque()
        q.append((root, None))
        node_to_delete = None
        last_node = None
        last_parent = None

        # Level-order traversal to find node_to_delete and deepest (last_node)
        while q:
            node, parent = q.popleft()
            if node.value == key:
                node_to_delete = node
            last_node = node
            last_parent = parent
            if node.left:
                q.append((node.left, node))
            if node.right:
                q.append((node.right, node))

        if node_to_delete:
            # replace target's value with deepest node's value
            node_to_delete.value = last_node.value
            # remove the deepest node from its parent
            if last_parent:
                if last_parent.left is last_node:
                    last_parent.left = None
                elif last_parent.right is last_node:
                    last_parent.right = None
            else:
                # last_node is root (should be handled earlier), but just in case:
                root = None

        return root

# Example usage
if __name__ == "__main__":
   
    tree = BinaryTree("R")
    
    # Insert nodes
    tree.insert_left(tree.root, "A")
    tree.insert_right(tree.root, "B")
    tree.insert_left(tree.root.left, "C")
    tree.insert_right(tree.root.left, "D")
    tree.insert_left(tree.root.right, "E")
    tree.insert_right(tree.root.right, "F")
    tree.insert_left(tree.root.right.right, "G")
    
    print()

    print("Preorder traversal: " + tree.preorder_traversal(tree.root,""))
    ##tree.preorder_traversal(tree.root,"")
    print("\n\nInorder traversal: " + tree.inorder_traversal(tree.root,""))
    # tree.inorder_traversal(tree.root)
    print("\n\nPostorder traversal: " + tree.post_traversal(tree.root,""))
 
    # tree.postorder_traversal(tree.root)
    print()