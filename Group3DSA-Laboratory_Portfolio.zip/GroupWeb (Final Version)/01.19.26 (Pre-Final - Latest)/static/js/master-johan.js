// Master Johan Interactive Robot Character
let masterJohanInitialized = false;
let masterJohanSayFunction = null;

function initMasterJohan() {
    // Master Johan cursor disabled - using standard cursor instead
    return;
    
    if (masterJohanInitialized) return;
    masterJohanInitialized = true;
    
    const johan = document.getElementById('master-johan');
    const johanSvg = document.getElementById('johan-svg');
    const johanBody = document.getElementById('johan-body');
    const johanHead = document.getElementById('johan-head');
    const speechBubble = document.getElementById('johan-speech');
    const johanText = document.getElementById('johan-text');
    
    if (!johan || !johanSvg) return;
    
    johan.classList.add('hidden'); // Keep hidden
    
    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;
    let johanX = 50;
    let johanY = 50;
    let targetX = 50;
    let targetY = 50;
    let currentEmotion = 'happy'; // happy, excited, sad, angry, frustrated, hoping
    let lastMoveTime = Date.now();
    let idleTimer = null;
    let currentSection = null;
    let lastClickTime = 0;
    
    // Emotions with colors
    const emotions = {
        happy: { color: '#38bdf8', glow: '#67e8f9' },
        excited: { color: '#facc15', glow: '#fde047' },
        sad: { color: '#60a5fa', glow: '#93c5fd' },
        angry: { color: '#f87171', glow: '#fca5a5' },
        frustrated: { color: '#fb923c', glow: '#fdba74' },
        hoping: { color: '#a855f7', glow: '#c084fc' }
    };
    
    // Dialogue system
    const dialogues = {
        idle: [
            "Hello! I'm Master Johan! 👋",
            "Ready to learn about data structures?",
            "Click me to see my reactions!",
            "Hover over different sections to explore!",
            "Let's dive into the world of algorithms!",
            "I'm here to guide you through everything!",
            "Data structures are so fascinating!",
            "Want to see something cool? Try clicking!",
        ],
        home: [
            "Welcome to Master Johan Labs!",
            "This is the home section. Scroll down to explore!",
            "Ready to learn about data structures?",
        ],
        team: [
            "Meet the amazing team behind this project!",
            "These are the talented developers of Master Johan Labs!",
            "Want to know more about each member?",
        ],
        dataStructures: [
            "Here's where the magic happens!",
            "Open the side panel to explore data structures!",
            "Each structure has an interactive guide prepared by me!",
            "Click the book icon to get started!",
            "Try interacting with the data structures below!",
            "Watch how Master Johan reacts when you manipulate the visualizations!",
        ],
        moving: [
            "Let's explore this section!",
            "Moving around, I see!",
            "There's so much to discover here!",
        ]
    };
    
    // Change emotion
    function setEmotion(emotion) {
        if (!emotions[emotion] || currentEmotion === emotion) return;
        currentEmotion = emotion;
        const { color, glow } = emotions[emotion];
        
        if (johanBody) {
            johanBody.style.fill = color;
            johanBody.style.transition = 'fill 0.3s ease';
        }
        if (johanHead) {
            johanHead.style.fill = color;
            johanHead.style.transition = 'fill 0.3s ease';
        }
        
        // Add glow effect
        johanSvg.style.filter = `drop-shadow(0 0 10px ${glow})`;
    }
    
    // Show speech bubble
    function say(text, duration = 3000) {
        if (!speechBubble || !johanText) return;
        
        johanText.textContent = text;
        speechBubble.classList.remove('hidden');
        
        setTimeout(() => {
            speechBubble.classList.add('fade-in');
        }, 10);
        
        setTimeout(() => {
            speechBubble.classList.remove('fade-in');
            speechBubble.classList.add('fade-out');
            
            setTimeout(() => {
                speechBubble.classList.add('hidden');
                speechBubble.classList.remove('fade-out');
            }, 300);
        }, duration);
    }
    
    // Expose say function globally (will be wrapped by global function below)
    masterJohanSayFunction = say;
    
    // Get current section based on scroll position
    function getCurrentSection() {
        const sections = {
            home: document.getElementById('home') || document.querySelector('header.hero'),
            team: document.getElementById('team'),
            dataStructures: document.getElementById('data-structures')
        };
        
        const scrollY = window.scrollY + 200;
        
        for (const [key, element] of Object.entries(sections)) {
            if (element) {
                const rect = element.getBoundingClientRect();
                const elementTop = rect.top + window.scrollY;
                const elementBottom = elementTop + rect.height;
                
                if (scrollY >= elementTop && scrollY < elementBottom) {
                    return key;
                }
            }
        }
        
        return 'home';
    }
    
    // Handle section changes
    function handleSectionChange() {
        const newSection = getCurrentSection();
        
        if (newSection !== currentSection) {
            currentSection = newSection;
            const sectionDialogue = dialogues[newSection] || dialogues.idle;
            const randomDialogue = sectionDialogue[Math.floor(Math.random() * sectionDialogue.length)];
            say(randomDialogue);
            setEmotion('excited');
            
            setTimeout(() => {
                setEmotion('happy');
            }, 2000);
        }
    }
    
    // Follow mouse with smooth animation and offset (so clicks pass through)
    function followMouse() {
        const easing = 0.15; // Slightly faster following
        
        // Check if panel is open - if so, keep Johan away from it
        const dsPanel = document.getElementById('ds-side-panel');
        const isPanelOpen = dsPanel && dsPanel.classList.contains('is-open');
        
        let offsetX = 50; // Offset to the right of cursor
        let offsetY = 50; // Offset below cursor
        
        // If panel is open and cursor is near the right side, move Johan further left
        if (isPanelOpen && mouseX > window.innerWidth * 0.7) {
            offsetX = -80; // Move Johan to the left side of cursor
        }
        
        // Offset Johan from cursor so he doesn't block clicks
        targetX = mouseX + offsetX;
        targetY = mouseY + offsetY;
        
        // Keep Johan within viewport bounds
        targetX = Math.max(30, Math.min(targetX, window.innerWidth - 30));
        targetY = Math.max(40, Math.min(targetY, window.innerHeight - 40));
        
        johanX += (targetX - johanX) * easing;
        johanY += (targetY - johanY) * easing;
        
        johan.style.left = `${johanX - 30}px`;
        johan.style.top = `${johanY - 37.5}px`;
        
        // Check if moving
        if (Math.abs(targetX - johanX) > 5 || Math.abs(targetY - johanY) > 5) {
            lastMoveTime = Date.now();
            clearTimeout(idleTimer);
        }
        
        requestAnimationFrame(followMouse);
    }
    
    // Handle idle state
    function checkIdle() {
        const timeSinceMove = Date.now() - lastMoveTime;
        
        if (timeSinceMove > 5000 && !speechBubble.classList.contains('fade-in')) {
            const idleDialogue = dialogues.idle[Math.floor(Math.random() * dialogues.idle.length)];
            say(idleDialogue);
            setEmotion('hoping');
            
            setTimeout(() => {
                setEmotion('happy');
            }, 2000);
            
            lastMoveTime = Date.now() + 5000; // Prevent spam
        }
        
        idleTimer = setTimeout(checkIdle, 1000);
    }
    
    // Mouse move handler
    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        
        // Occasional dialogue when moving
        if (Math.random() > 0.98 && !speechBubble.classList.contains('fade-in')) {
            const movingDialogue = dialogues.moving[Math.floor(Math.random() * dialogues.moving.length)];
            say(movingDialogue, 2000);
        }
    });
    
    // Click handler - screen slap animation (only if clicking directly on Johan)
    // Use bubbling phase so we don't interfere with other handlers
    document.addEventListener('click', (e) => {
        // Always allow clicks on interactive elements to proceed normally
        const target = e.target;
        const isInteractive = target.tagName === 'BUTTON' || 
            target.tagName === 'A' || 
            target.tagName === 'INPUT' ||
            target.tagName === 'FORM' ||
            target.closest('button') ||
            target.closest('a') ||
            target.closest('input') ||
            target.closest('form') ||
            target.closest('.ds-side-panel') ||
            target.closest('.ds-panel-toggle') ||
            target.closest('.book-page') ||
            target.closest('.book-nav-btn') ||
            target.closest('.ds-panel-close');
        
        if (isInteractive) {
            // Just do a subtle animation without interfering
            return; // Don't do anything, let the click proceed
        }
        
        const now = Date.now();
        if (now - lastClickTime < 300) return; // Debounce
        lastClickTime = now;
        
        // Check if clicked directly on Johan (with smaller hitbox)
        const johanRect = johan.getBoundingClientRect();
        const johanCenterX = johanRect.left + johanRect.width / 2;
        const johanCenterY = johanRect.top + johanRect.height / 2;
        const distance = Math.sqrt(
            Math.pow(e.clientX - johanCenterX, 2) +
            Math.pow(e.clientY - johanCenterY, 2)
        );
        
        if (distance < 50) {
            // Clicked directly on Johan - slap animation (only if not a button click)
            if (!target.closest('button') && !target.closest('a')) {
                setEmotion('excited');
                johan.style.transform = 'rotate(15deg) scale(1.2)';
                
                setTimeout(() => {
                    johan.style.transform = 'rotate(-15deg) scale(1.2)';
                    say("Hey! 😄", 1500);
                }, 100);
                
                setTimeout(() => {
                    johan.style.transform = 'rotate(0deg) scale(1)';
                    setEmotion('happy');
                }, 200);
            }
        } else {
            // Regular click - subtle screen slap effect at click position
            // Only show animation for non-interactive clicks
            setEmotion('excited');
            johan.style.animation = 'johan-slap 0.2s ease';
            
            // Create visual effect at click position
            const ripple = document.createElement('div');
            ripple.className = 'johan-ripple';
            ripple.style.left = `${e.clientX}px`;
            ripple.style.top = `${e.clientY}px`;
            document.body.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
                setEmotion('happy');
                johan.style.animation = '';
            }, 200);
        }
    });
    
    // Scroll handler for section detection
    let scrollTimeout;
    window.addEventListener('scroll', () => {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(handleSectionChange, 200);
    });
    
    // Initialize Johan position
    johan.style.left = '50px';
    johan.style.top = '50px';
    johanX = 80;
    johanY = 87.5;
    
    // Start following mouse
    followMouse();
    
    // Start idle check
    setTimeout(() => {
        checkIdle();
        say("Welcome! I'm Master Johan, your guide! 👋", 3000);
    }, 1000);
    
    // Periodic section check
    setInterval(handleSectionChange, 2000);
    
    // Initial emotion
    setEmotion('happy');
}

// Global function to make Master Johan speak (called from other scripts)
window.masterJohanSay = function(text, duration = 3000) {
    if (masterJohanSayFunction) {
        masterJohanSayFunction(text, duration);
    } else {
        // If Master Johan hasn't been initialized yet, wait and try again
        setTimeout(() => {
            if (masterJohanSayFunction) {
                masterJohanSayFunction(text, duration);
            }
        }, 500);
    }
};

// Export for loading screen
window.initMasterJohan = initMasterJohan;

// Initialize if page already loaded
if (document.body.classList.contains('loaded')) {
    setTimeout(initMasterJohan, 500);
}
