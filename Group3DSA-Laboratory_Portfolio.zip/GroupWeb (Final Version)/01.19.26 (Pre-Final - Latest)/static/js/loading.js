// Loading Screen Implementation
document.addEventListener('DOMContentLoaded', () => {
    const loadingScreen = document.getElementById('loading-screen');
    const loadingProgress = document.getElementById('loading-progress');
    const loadingPercentage = document.getElementById('loading-percentage');
    const loadingMessage = document.getElementById('loading-message');
    const johanLoading = document.getElementById('johan-loading');
    
    if (!loadingScreen) return;
    
    // Skip loading screen only when arriving after a BT/BST form action.
    // Flask routes redirect to '/#bt-section' or '/#bst-section' after form submissions,
    // so we check the URL hash instead of hiding on initial page load.
    const hash = window.location.hash;
    if (hash === '#bt-section' || hash === '#bst-section') {
        loadingScreen.style.display = 'none';
        document.body.classList.add('loaded');
        if (window.initMasterJohan) {
            window.initMasterJohan();
        }
        return;
    }
    
    let progress = 0;
    const targetProgress = 100;
    const duration = 2000; 
    const intervalTime = 20;
    const totalSteps = duration / intervalTime;
    const progressPerStep = targetProgress / totalSteps;
    
    // Loading messages that Master Johan says
    const loadingMessages = [
        "Initializing Master Johan...",
        "Loading magical powers...",
        "Preparing retro game vibes...",
        "Charging glowing effects...",
        "Almost ready to explore!",
        "Just a moment more...",
        "Entering the data structure realm...",
        "Finalizing everything..."
    ];
    
    let messageIndex = 0;
    const messageInterval = duration / loadingMessages.length;
    let messageTimer = 0;
    
    // Animate Johan during loading
    const animateJohan = () => {
        if (!johanLoading) return;
        const johanSvg = johanLoading.querySelector('.johan-svg');
        if (!johanSvg) return;
        
        // Bouncing animation
        johanSvg.style.animation = 'johan-bounce 1s ease-in-out infinite';
        
        // Eye blinking
        const eyes = johanSvg.querySelectorAll('.johan-eye');
        setInterval(() => {
            eyes.forEach(eye => {
                eye.style.opacity = '0.2';
                setTimeout(() => {
                    eye.style.opacity = '1';
                }, 100);
            });
        }, 2000);
    };
    
    animateJohan();
    
    // Update progress
    const updateProgress = () => {
        progress += progressPerStep;
        
        if (progress > targetProgress) {
            progress = targetProgress;
        }
        
        loadingProgress.style.width = `${progress}%`;
        loadingPercentage.textContent = `${Math.floor(progress)}%`;
        
        // Update loading message
        messageTimer += intervalTime;
        if (messageTimer >= messageInterval && messageIndex < loadingMessages.length - 1) {
            messageIndex++;
            loadingMessage.textContent = loadingMessages[messageIndex];
            messageTimer = 0;
        }
        
        if (progress >= targetProgress) {
            // Loading complete
            loadingMessage.textContent = "Ready! Welcome to Master Johan Labs!";
            loadingMessage.classList.add('complete');
            
            setTimeout(() => {
                loadingScreen.classList.add('fade-out');
                
                setTimeout(() => {
                    loadingScreen.style.display = 'none';
                    document.body.classList.add('loaded');
                    
                    // Initialize Master Johan after loading
                    if (window.initMasterJohan) {
                        window.initMasterJohan();
                    }
                }, 150);
            }, 100);
        } else {
            setTimeout(updateProgress, intervalTime);
        }
    };
    
    // Start loading animation
    setTimeout(() => {
        updateProgress();
    }, 100);
});
