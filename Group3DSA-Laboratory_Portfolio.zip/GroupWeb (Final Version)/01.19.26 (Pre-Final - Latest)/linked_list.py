class LinkedList:
    def __init__(self):
        self.items = []

    def add(self, value):
        self.items.append(value)

    def remove(self):
        if self.is_empty():
           raise Exception("Linked list is empty")
        return self.items.pop(0)

    def peek(self):
        return self.items[0] if not self.is_empty() else None

    def is_empty(self):
        return len(self.items) == 0

    def size(self):
        return len(self.items)

    def get_all(self):
        return self.items

