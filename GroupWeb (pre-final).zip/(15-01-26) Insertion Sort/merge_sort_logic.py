def add_frame(history, arr, color_map, message):
    """Helper to record a snapshot."""
    history.append({
        'arr': list(arr),
        'colors': color_map.copy(),
        'message': message
    })

def merge(arr, left, mid, right, history):
    n1 = mid - left + 1
    n2 = right - mid
    L = [0] * n1
    R = [0] * n2

    for i in range(n1): L[i] = arr[left + i]
    for j in range(n2): R[j] = arr[mid + 1 + j]

    i = 0; j = 0; k = left 

    # VISUAL: Highlight segments
    base_colors = {}
    for x in range(left, mid + 1): base_colors[x] = 'segment-left'
    for x in range(mid + 1, right + 1): base_colors[x] = 'segment-right'
    
    add_frame(history, arr, base_colors, f"Merging segments [{left}-{mid}] and [{mid+1}-{right}]")

    while i < n1 and j < n2:
        comp_colors = base_colors.copy()
        real_idx_L = left + i
        real_idx_R = mid + 1 + j
        comp_colors[real_idx_L] = 'comparing'
        comp_colors[real_idx_R] = 'comparing'
        
        add_frame(history, arr, comp_colors, f"Comparing {L[i]} and {R[j]}")

        if L[i] <= R[j]:
            arr[k] = L[i]
            i += 1
        else:
            arr[k] = R[j]
            j += 1
        
        add_frame(history, arr, base_colors, f"Placed {arr[k]} at position {k}")
        k += 1

    while i < n1:
        arr[k] = L[i]
        i += 1
        add_frame(history, arr, base_colors, "Remaining items from left side")
        k += 1

    while j < n2:
        arr[k] = R[j]
        j += 1
        add_frame(history, arr, base_colors, "Remaining items from right side")
        k += 1

def merge_sort_recursive(arr, left, right, history):
    if left < right:
        mid = (left + right) // 2
        
        # VISUAL: Divide
        range_colors = {}
        for x in range(left, right + 1): range_colors[x] = 'dividing'
        add_frame(history, arr, range_colors, f"Dividing range [{left}-{right}]")

        merge_sort_recursive(arr, left, mid, history)
        merge_sort_recursive(arr, mid + 1, right, history)
        merge(arr, left, mid, right, history)

def get_merge_sort_history(arr):
    """Main entry point called by app.py"""
    history = []
    # Initial State
    add_frame(history, arr, {}, "Start Sorting")
    
    # Run Sort
    merge_sort_recursive(arr, 0, len(arr) - 1, history)
    
    # Final State
    final_colors = {i: 'sorted' for i in range(len(arr))}
    add_frame(history, arr, final_colors, "Sorting Complete!")
    
    return arr, history