const select = (selector) => document.querySelector(selector);
const selectAll = (selector) => Array.from(document.querySelectorAll(selector));

const createNodeElement = (value) => {
    const div = document.createElement('div');
    div.className = 'node';
    div.textContent = value;
    return div;
};

const setEmptyState = (container, message = 'Add elements to begin visualizing.') => {
    container.innerHTML = `<p class="empty-state">${message}</p>`;
};

const bstCompare = (a, b) => {
    const isNumA = typeof a === 'number';
    const isNumB = typeof b === 'number';

    if (isNumA && isNumB) {
        return a - b;
    }

    return String(a).localeCompare(String(b));
};

const normalizeValue = (value) => {
    const trimmed = value.trim();
    if (!trimmed) {
        return null;
    }
    const maybeNumber = Number(trimmed);
    return Number.isNaN(maybeNumber) ? trimmed : maybeNumber;
};

const insertBst = (node, value) => {
    if (!node) {
        return { value, left: null, right: null };
    }

    if (bstCompare(value, node.value) < 0) {
        node.left = insertBst(node.left, value);
    } else {
        node.right = insertBst(node.right, value);
    }

    return node;
};

const inorderTraversal = (node, acc = []) => {
    if (!node) return acc;
    inorderTraversal(node.left, acc);
    acc.push(node.value);
    inorderTraversal(node.right, acc);
    return acc;
};

const buildBstLevels = (root) => {
    const levels = [];
    const queue = [{ node: root, depth: 0 }];

    while (queue.length) {
        const { node, depth } = queue.shift();
        if (!levels[depth]) {
            levels[depth] = [];
        }
        levels[depth].push(node.value);

        if (node.left) queue.push({ node: node.left, depth: depth + 1 });
        if (node.right) queue.push({ node: node.right, depth: depth + 1 });
    }

    return levels;
};

// Debug: Log when script loads
console.log('Data Structures script loading...');

document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM Content Loaded - Initializing data structures...');

    const navToggle = select('[data-nav-toggle]');
    const navPanel = select('[data-nav-panel]');
    const submenuToggle = select('[data-sub-toggle]');
    const submenu = select('[data-submenu]');

    const toggleNav = () => {
        navPanel.classList.toggle('is-open');
        navToggle.classList.toggle('is-open');
    };

    navToggle?.addEventListener('click', toggleNav);

    submenuToggle?.addEventListener('click', () => {
        submenu?.classList.toggle('is-open');
    });

    selectAll('.nav-panel a').forEach((link) => {
        link.addEventListener('click', () => {
            if (navPanel.classList.contains('is-open')) {
                toggleNav();
            }
        });
    });

    // State objects removed - each visualization now has its own isolated state

    /* Linked List - Handle multiple instances (main page + book pages) */
    const initializeLinkedList = (container, llVisual) => {
        const llInput = container.querySelector('[data-ll-input]');
        const llVisualEl = llVisual || container.querySelector('[data-ll-visual]');
        const llAdd = container.querySelector('[data-ll-add]');
        const llRemove = container.querySelector('[data-ll-remove]');

        if (!llVisualEl) {
            console.warn('Linked List visual not found in container:', container);
            return;
        }

        // Each container has its own state
        const linkedListState = [];

        const renderLinkedList = () => {
            if (!linkedListState.length) {
                setEmptyState(llVisualEl, 'Linked list is empty.');
                return;
            }
            llVisualEl.innerHTML = '';
            linkedListState.forEach((value) => {
                const node = createNodeElement(value);
                llVisualEl.appendChild(node);
            });
        };

        llAdd?.addEventListener('click', () => {
            const value = normalizeValue(llInput?.value || '');
            if (value === null || !value) return;
            linkedListState.push(value);
            if (llInput) llInput.value = '';
            renderLinkedList();

            // Master Johan reaction
            if (window.masterJohanSay) {
                window.masterJohanSay(`Added ${value} to the linked list! 🔗`, 2000);
            }
        });

        llRemove?.addEventListener('click', () => {
            if (linkedListState.length > 0) {
                linkedListState.shift();
                renderLinkedList();
            }
        });

        // Initialize empty state
        renderLinkedList();

        // Handle Enter key
        llInput?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && llAdd) {
                llAdd.click();
            }
        });
    };

    // Initialize all Linked List instances (main page + book pages)
    console.log('Initializing Linked List visualizations...');
    const llVisuals = selectAll('[data-ll-visual]');
    console.log(`Found ${llVisuals.length} Linked List visualizations`);

    llVisuals.forEach((visual, index) => {
        const container = visual.closest('.ds-card, .book-page, .page-content') ||
            visual.closest('[data-ds="linked-list"]') ||
            visual.parentElement;
        if (container) {
            console.log(`Initializing Linked List ${index + 1} in container:`, container.className);
            initializeLinkedList(container, visual);
        } else {
            console.warn('Linked List container not found for visual:', visual);
        }
    });

    /* Stack - Handle multiple instances (main page + book pages) */
    const initializeStack = (container, stackVisual) => {
        const stackInput = container.querySelector('[data-stack-input]');
        const stackVisualEl = stackVisual || container.querySelector('[data-stack-visual]');
        const stackPush = container.querySelector('[data-stack-push]');
        const stackPop = container.querySelector('[data-stack-pop]');

        if (!stackVisualEl) {
            console.warn('Stack visual not found in container:', container);
            return;
        }

        // Each container has its own state
        const stackState = [];

        const renderStack = () => {
            if (!stackState.length) {
                setEmptyState(stackVisualEl, 'Stack is empty.');
                return;
            }
            stackVisualEl.innerHTML = '';
            // Render in reverse order for stack visualization (top to bottom)
            [...stackState].reverse().forEach((value) => {
                const node = createNodeElement(value);
                stackVisualEl.appendChild(node);
            });
        };

        stackPush?.addEventListener('click', () => {
            const value = normalizeValue(stackInput?.value || '');
            if (value === null || !value) return;
            stackState.push(value);
            if (stackInput) stackInput.value = '';
            renderStack();

            // Master Johan reaction
            if (window.masterJohanSay) {
                window.masterJohanSay(`Pushed ${value} onto the stack! 📚`, 2000);
            }
        });

        stackPop?.addEventListener('click', () => {
            if (stackState.length > 0) {
                stackState.pop();
                renderStack();
            }
        });

        // Initialize empty state
        renderStack();

        // Handle Enter key
        stackInput?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && stackPush) {
                stackPush.click();
            }
        });
    };

    // Initialize all Stack instances (main page + book pages)
    console.log('Initializing Stack visualizations...');
    const stackVisuals = selectAll('[data-stack-visual]');
    console.log(`Found ${stackVisuals.length} Stack visualizations`);

    stackVisuals.forEach((visual, index) => {
        const container = visual.closest('.ds-card, .book-page, .page-content') ||
            visual.closest('[data-ds="stack"]') ||
            visual.parentElement;
        if (container) {
            console.log(`Initializing Stack ${index + 1} in container:`, container.className);
            initializeStack(container, visual);
        } else {
            console.warn('Stack container not found for visual:', visual);
        }
    });

    /* Queue - Handle multiple instances (main page + book pages) */
    const initializeQueue = (container, queueVisual) => {
        const queueInput = container.querySelector('[data-queue-input]');
        const queueVisualEl = queueVisual || container.querySelector('[data-queue-visual]');
        const queueEnqueue = container.querySelector('[data-queue-enqueue]');
        const queueDequeue = container.querySelector('[data-queue-dequeue]');

        if (!queueVisualEl) {
            console.warn('Queue visual not found in container:', container);
            return;
        }

        // Each container has its own state
        const queueState = [];

        const renderQueue = () => {
            if (!queueState.length) {
                setEmptyState(queueVisualEl, 'Queue is empty.');
                return;
            }
            queueVisualEl.innerHTML = '';
            queueState.forEach((value, index) => {
                const node = createNodeElement(value);
                node.dataset.position = index === 0 ? 'Front' : index === queueState.length - 1 ? 'Rear' : '';
                queueVisualEl.appendChild(node);
            });
        };

        queueEnqueue?.addEventListener('click', () => {
            const value = normalizeValue(queueInput?.value || '');
            if (value === null || !value) return;
            queueState.push(value);
            if (queueInput) queueInput.value = '';
            renderQueue();

            // Master Johan reaction
            if (window.masterJohanSay) {
                window.masterJohanSay(`Enqueued ${value} to the queue! 📋`, 2000);
            }
        });

        queueDequeue?.addEventListener('click', () => {
            if (queueState.length > 0) {
                queueState.shift();
                renderQueue();
            }
        });

        // Initialize empty state
        renderQueue();

        // Handle Enter key
        queueInput?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && queueEnqueue) {
                queueEnqueue.click();
            }
        });
    };

    // Initialize all Queue instances (main page + book pages)
    console.log('Initializing Queue visualizations...');
    const queueVisuals = selectAll('[data-queue-visual]');
    console.log(`Found ${queueVisuals.length} Queue visualizations`);

    queueVisuals.forEach((visual, index) => {
        const container = visual.closest('.ds-card, .book-page, .page-content') ||
            visual.closest('[data-ds="queue"]') ||
            visual.parentElement;
        if (container) {
            console.log(`Initializing Queue ${index + 1} in container:`, container.className);
            initializeQueue(container, visual);
        } else {
            console.warn('Queue container not found for visual:', visual);
        }
    });
    /* Binary Tree and BST use Flask forms - they work server-side */
    // Handle form submissions to preserve panel state and reload tree visualizations
    // Store panel state before form submission to restore it after reload
    const savePanelState = () => {
        const dsPanel = document.getElementById('ds-side-panel');
        if (dsPanel && dsPanel.classList.contains('is-open')) {
            sessionStorage.setItem('dsPanelOpen', 'true');
            const currentPage = document.querySelector('.book-page.active');
            if (currentPage) {
                const pageIndex = Array.from(document.querySelectorAll('.book-page')).indexOf(currentPage);
                sessionStorage.setItem('dsPanelPage', pageIndex.toString());
            }
        } else {
            sessionStorage.removeItem('dsPanelOpen');
            sessionStorage.removeItem('dsPanelPage');
        }
    };

    // Restore panel state on page load - check both sessionStorage and URL params
    // This will be called after showPage is defined
    const restorePanelStateOnLoad = () => {
        // Check URL parameters first (from Flask redirect)
        const urlParams = new URLSearchParams(window.location.search);
        const panelOpenParam = urlParams.get('panel_open');
        const panelPageParam = urlParams.get('panel_page');

        const dsPanel = document.getElementById('ds-side-panel');
        const bookPages = document.querySelectorAll('.book-page');

        // Check sessionStorage if URL params not present
        const panelOpen = panelOpenParam === 'true' || sessionStorage.getItem('dsPanelOpen') === 'true';
        const pageIndex = panelPageParam ? parseInt(panelPageParam) : parseInt(sessionStorage.getItem('dsPanelPage') || '0');

        if (panelOpen && dsPanel && bookPages.length > 0) {
            // Open panel first
            dsPanel.classList.add('is-open');

            // Then show the correct page - wait for showPage to be defined
            const tryRestorePage = () => {
                if (pageIndex >= 0 && pageIndex < bookPages.length) {
                    if (window.showPage) {
                        window.showPage(pageIndex);
                    } else {
                        // Fallback if showPage not ready yet
                        bookPages.forEach((page, i) => {
                            if (i === pageIndex) {
                                page.classList.add('active');
                                page.style.display = 'block';
                                page.style.opacity = '1';
                            } else {
                                page.classList.remove('active');
                                page.style.display = 'none';
                                page.style.opacity = '0';
                            }
                        });
                        // Update indicators
                        const currentPageIndicator = document.getElementById('current-page');
                        const bookPrev = document.getElementById('book-prev');
                        const bookNext = document.getElementById('book-next');
                        if (currentPageIndicator) currentPageIndicator.textContent = pageIndex + 1;
                        if (bookPrev) bookPrev.disabled = pageIndex === 0;
                        if (bookNext) bookNext.disabled = pageIndex === bookPages.length - 1;
                    }
                }
            };

            // Try immediately and also with a delay
            tryRestorePage();
            setTimeout(tryRestorePage, 200);

            // Clean up URL params after restoring
            if (panelOpenParam) {
                setTimeout(() => {
                    window.history.replaceState({}, '', window.location.pathname + window.location.hash);
                }, 500);
            }
        }
    };

    // Handle all Binary Tree and BST forms - intercept and preserve state
    const handleTreeFormSubmit = (form) => {
        form.addEventListener('submit', (e) => {
            savePanelState();

            const dsPanel = document.getElementById('ds-side-panel');
            const isPanelOpen = dsPanel && dsPanel.classList.contains('is-open');
            const currentPage = document.querySelector('.book-page.active');
            const pageIndex = currentPage ? Array.from(document.querySelectorAll('.book-page')).indexOf(currentPage) : 0;

            console.log('Form submitting, panel open:', isPanelOpen, 'page:', pageIndex); // Debug

            // Add hidden inputs for panel state
            if (isPanelOpen) {
                // Remove existing hidden inputs if any
                form.querySelectorAll('input[name="panel_open"], input[name="panel_page"]').forEach(input => input.remove());

                const panelOpenInput = document.createElement('input');
                panelOpenInput.type = 'hidden';
                panelOpenInput.name = 'panel_open';
                panelOpenInput.value = 'true';
                form.appendChild(panelOpenInput);

                const panelPageInput = document.createElement('input');
                panelPageInput.type = 'hidden';
                panelPageInput.name = 'panel_page';
                panelPageInput.value = pageIndex.toString();
                form.appendChild(panelPageInput);

                console.log('Added panel state to form:', { panel_open: 'true', panel_page: pageIndex }); // Debug
            }

            // Let form submit normally - Flask will handle it with state
        });
    };

    // Apply to all Binary Tree and BST forms - use more flexible matching
    const treeFormSelectors = [
        'form[action="/bt_insert"]',
        'form[action^="/bt_traverse/"]', // Matches /bt_traverse/preorder, etc.
        'form[action="/bt_clear"]',
        'form[action="/bst_insert"]',
        'form[action="/bst_delete"]',
        'form[action="/bst_clear"]'
    ];

    treeFormSelectors.forEach(selector => {
        selectAll(selector).forEach(form => {
            console.log('Found tree form:', form.action); // Debug
            handleTreeFormSubmit(form);
        });
    });

    // Also handle any forms with bt_ or bst_ in action as fallback
    selectAll('form[action*="/bt_"], form[action*="/bst_"]').forEach(form => {
        if (!form.hasAttribute('data-form-handled')) {
            form.setAttribute('data-form-handled', 'true');
            handleTreeFormSubmit(form);
        }
    });

    // Add Enter key support for form inputs
    selectAll('input[type="text"][name="value"]').forEach(input => {
        const form = input.closest('form');
        if (form && (form.action.includes('/bt_') || form.action.includes('/bst_'))) {
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    savePanelState();
                    const submitBtn = form.querySelector('button[type="submit"]');
                    if (submitBtn) {
                        submitBtn.click();
                    } else {
                        form.submit();
                    }
                }
            });
        }
    });

    /* Data Structures Side Panel and Book Navigation */
    console.log('Initializing Data Structures panel...');

    const dsPanel = document.getElementById('ds-side-panel');
    const dsPanelToggle = document.getElementById('ds-panel-toggle');
    const dsPanelClose = document.getElementById('ds-panel-close');
    const openDsPanelBtn = document.getElementById('open-ds-panel-btn');
    const bookPages = document.querySelectorAll('.book-page');
    const bookPrev = document.getElementById('book-prev');
    const bookNext = document.getElementById('book-next');
    const currentPageIndicator = document.getElementById('current-page');
    const totalPagesIndicator = document.getElementById('total-pages');

    console.log(`Found ${bookPages.length} book pages`); // Debug
    console.log(`Panel element:`, dsPanel); // Debug
    console.log(`Toggle button:`, dsPanelToggle); // Debug
    console.log(`Open button:`, openDsPanelBtn); // Debug

    let currentPageIndex = 0;

    // Set total pages
    if (totalPagesIndicator && bookPages.length) {
        totalPagesIndicator.textContent = bookPages.length;
        console.log(`Total pages set to: ${bookPages.length}`);
    } else {
        console.warn('Total pages indicator or book pages not found!');
    }

    // Open/close panel
    function openDsPanel() {
        if (dsPanel) {
            dsPanel.classList.add('is-open');
            console.log('Data Structures panel opened'); // Debug
        } else {
            console.error('Data Structures panel element not found'); // Debug
        }
    }

    function closeDsPanel() {
        if (dsPanel) {
            dsPanel.classList.remove('is-open');
        }
    }

    if (dsPanelToggle && dsPanel) {
        dsPanelToggle.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent Master Johan from interfering
            dsPanel.classList.toggle('is-open');
        });
    }

    if (dsPanelClose && dsPanel) {
        dsPanelClose.addEventListener('click', (e) => {
            e.stopPropagation();
            closeDsPanel();
        });
    }

    if (openDsPanelBtn && dsPanel) {
        openDsPanelBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent Master Johan from interfering
            e.preventDefault(); // Prevent any default behavior
            openDsPanel();

            // Trigger Master Johan dialogue
            if (window.masterJohanSay) {
                setTimeout(() => {
                    window.masterJohanSay("Great! Let's explore data structures together! 📚", 3000);
                }, 500);
            }
        });
    }

    // Book navigation - make globally accessible
    function showPage(index) {
        const bookPages = document.querySelectorAll('.book-page');
        const currentPageIndicator = document.getElementById('current-page');
        const bookPrev = document.getElementById('book-prev');
        const bookNext = document.getElementById('book-next');

        if (index < 0 || index >= bookPages.length) {
            console.warn(`Invalid page index: ${index}`); // Debug
            return;
        }

        console.log(`Showing page ${index + 1} of ${bookPages.length}`); // Debug

        bookPages.forEach((page, i) => {
            if (i === index) {
                page.classList.add('active');
                page.style.display = 'block';
                page.style.opacity = '1';
            } else {
                page.classList.remove('active');
                page.style.display = 'none';
                page.style.opacity = '0';
            }
        });

        currentPageIndex = index;

        if (currentPageIndicator) {
            currentPageIndicator.textContent = index + 1;
        }

        // Update button states
        if (bookPrev) {
            bookPrev.disabled = index === 0;
        }
        if (bookNext) {
            bookNext.disabled = index === bookPages.length - 1;
        }

        // Trigger Master Johan dialogue if available
        if (window.masterJohanSay) {
            const dsType = bookPages[index].dataset.ds;
            const messages = {
                'binary-tree': 'Binary trees organize data hierarchically! Each node can have up to two children. Try the traversal methods! 🌳',
                'graph': 'Graphs model relationships! BFS finds the shortest path - perfect for navigation! Click to explore the MRT tool! 🗺️',
                'linked-list': 'Linked lists are dynamic and flexible! Perfect when you don\'t know the size in advance. Each node points to the next! 🔗',
                'queue': 'Queues follow FIFO - First In, First Out! Like waiting in line, the first person joins first and leaves first! 📋',
                'stack': 'Stacks follow LIFO - Last In, First Out! Like a stack of plates, you take from the top! The most recent item is removed first! 📚',
                'bst': 'Binary Search Trees enable O(log n) searching! Values are organized: smaller left, larger right. Inorder traversal gives sorted order! 🔍'
            };
            if (messages[dsType]) {
                setTimeout(() => {
                    window.masterJohanSay(messages[dsType], 4000);
                }, 500);
            }
        }
    }

    // Make showPage globally accessible
    window.showPage = showPage;

    if (bookPrev) {
        bookPrev.addEventListener('click', () => {
            if (currentPageIndex > 0) {
                showPage(currentPageIndex - 1);
            }
        });
    }

    if (bookNext) {
        bookNext.addEventListener('click', () => {
            if (currentPageIndex < bookPages.length - 1) {
                showPage(currentPageIndex + 1);
            }
        });
    }

    // Initialize first page or restore saved state
    if (bookPages.length > 0) {
        // Check if we need to restore panel state from URL (after form submission)
        const urlParams = new URLSearchParams(window.location.search);
        const panelOpenParam = urlParams.get('panel_open');
        const panelPageParam = urlParams.get('panel_page');

        if (panelOpenParam === 'true' && panelPageParam !== null) {
            // Restore to the page from URL (from form submission)
            const pageIndex = parseInt(panelPageParam);
            if (pageIndex >= 0 && pageIndex < bookPages.length) {
                // Open panel first, then show page
                if (dsPanel) {
                    dsPanel.classList.add('is-open');
                }
                setTimeout(() => {
                    showPage(pageIndex);
                }, 100);
            } else {
                showPage(0);
            }
        } else {
            // Normal initialization - show first page
            showPage(0);
        }

        console.log(`Initialized book with ${bookPages.length} pages`); // Debug

        // Also check sessionStorage and restore panel if needed (after delay)
        setTimeout(() => {
            restorePanelStateOnLoad();
        }, 300);
    } else {
        console.error('No book pages found!'); // Debug
    }

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (dsPanel && dsPanel.classList.contains('is-open')) {
            if (e.key === 'ArrowLeft' && currentPageIndex > 0) {
                showPage(currentPageIndex - 1);
            } else if (e.key === 'ArrowRight' && currentPageIndex < bookPages.length - 1) {
                showPage(currentPageIndex + 1);
            } else if (e.key === 'Escape') {
                closeDsPanel();
            }
        }
    });

    // Click outside to close
    if (dsPanel) {
        dsPanel.addEventListener('click', (e) => {
            if (e.target === dsPanel) {
                closeDsPanel();
            }
        });
    }
});

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Bubble Sort
async function startBubbleSort() {
    const input = document.getElementById('bubble-input')?.value;
    if (!input) return;

    const arr = input.split(',').map(x => parseInt(x.trim())).filter(x => !Number.isNaN(x));
    if (!arr.length) return;

    await runBubbleSort(arr, 'bubble');
}

async function runBubbleSort(inputArray, algoType) {
    const startBtn = document.querySelector(`button[onclick="startBubbleSort()"]`);
    const speedInput = document.getElementById('bubble-speed');
    const timerEl = document.getElementById('bubble-timer');
    const container = document.getElementById('bubble-container');

    if (startBtn) startBtn.disabled = true;
    if (speedInput) speedInput.disabled = true;

    const t0 = performance.now();
    timerEl.textContent = 'Time: 0 ms';
    const timerInterval = setInterval(() => {
        const dt = Math.round(performance.now() - t0);
        timerEl.textContent = `Time: ${dt} ms`;
    }, 50);

    let arr = [...inputArray];
    container.innerHTML = '';
    arr.forEach(val => {
        const bar = document.createElement('div');
        bar.className = 'bar';
        bar.style.height = `${val * 3}px`;
        const label = document.createElement('span');
        label.className = 'bar-label';
        label.textContent = val;
        bar.appendChild(label);
        container.appendChild(bar);
    });

    const bars = container.querySelectorAll('.bar');
    const n = arr.length;

    for (let i = 0; i < n; i++) {
        for (let j = 0; j < n - i - 1; j++) {
            bars[j].classList.add('highlight');
            bars[j + 1].classList.add('highlight');

            const speed = Number(speedInput?.value) || 150;
            await sleep(Math.max(10, speed));

            if (arr[j] > arr[j + 1]) {
                [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
                bars[j].style.height = `${arr[j] * 3}px`;
                bars[j + 1].style.height = `${arr[j + 1] * 3}px`;
                bars[j].querySelector('.bar-label').textContent = arr[j];
                bars[j + 1].querySelector('.bar-label').textContent = arr[j + 1];
                await sleep(Math.max(20, Math.floor((speedInput?.value || 150) / 3)));
            }

            bars[j].classList.remove('highlight');
            bars[j + 1].classList.remove('highlight');
        }
        bars[n - i - 1].classList.add('sorted');
    }

    clearInterval(timerInterval);
    const totalMs = Math.round(performance.now() - t0);
    timerEl.textContent = `Time: ${totalMs} ms`;
    if (startBtn) startBtn.disabled = false;
    if (speedInput) speedInput.disabled = false;
}

// Selection Sort
async function startSelectionSort() {
    const input = document.getElementById('selection-input')?.value;
    if (!input) return;

    const arr = input.split(',').map(x => parseInt(x.trim())).filter(x => !Number.isNaN(x));
    if (!arr.length) return;

    await runSelectionSort(arr);
}

async function runSelectionSort(inputArray) {
    const startBtn = document.querySelector(`button[onclick="startSelectionSort()"]`);
    const speedInput = document.getElementById('selection-speed');
    const timerEl = document.getElementById('selection-timer');
    const container = document.getElementById('selection-container');

    if (startBtn) startBtn.disabled = true;
    if (speedInput) speedInput.disabled = true;

    const t0 = performance.now();
    timerEl.textContent = 'Time: 0 ms';
    const timerInterval = setInterval(() => {
        const dt = Math.round(performance.now() - t0);
        timerEl.textContent = `Time: ${dt} ms`;
    }, 50);

    let arr = [...inputArray];
    container.innerHTML = '';
    arr.forEach(val => {
        const bar = document.createElement('div');
        bar.className = 'bar';
        bar.style.height = `${val * 3}px`;
        const label = document.createElement('span');
        label.className = 'bar-label';
        label.textContent = val;
        bar.appendChild(label);
        container.appendChild(bar);
    });

    const bars = container.querySelectorAll('.bar');

    for (let i = 0; i < arr.length; i++) {
        let min_idx = i;
        bars[i].classList.add('min');

        for (let j = i + 1; j < arr.length; j++) {
            bars[j].classList.add('highlight');

            const speed = Number(speedInput?.value) || 150;
            await sleep(Math.max(10, speed));

            if (arr[j] < arr[min_idx]) {
                bars[min_idx].classList.remove('min');
                min_idx = j;
                bars[min_idx].classList.add('min');
            }
            bars[j].classList.remove('highlight');
        }

        if (min_idx !== i) {
            [arr[i], arr[min_idx]] = [arr[min_idx], arr[i]];
            bars[i].style.height = `${arr[i] * 3}px`;
            bars[min_idx].style.height = `${arr[min_idx] * 3}px`;
            bars[i].querySelector('.bar-label').textContent = arr[i];
            bars[min_idx].querySelector('.bar-label').textContent = arr[min_idx];
            await sleep(Math.max(20, Math.floor((speedInput?.value || 150) / 3)));
        }

        bars[i].classList.remove('min');
        bars[i].classList.add('sorted');
    }

    clearInterval(timerInterval);
    const totalMs = Math.round(performance.now() - t0);
    timerEl.textContent = `Time: ${totalMs} ms`;
    if (startBtn) startBtn.disabled = false;
    if (speedInput) speedInput.disabled = false;
}

// Insertion Sort
async function startInsertionSort() {
    const input = document.getElementById('insertion-input')?.value;
    if (!input) return;

    const arr = input.split(',').map(x => parseInt(x.trim())).filter(x => !Number.isNaN(x));
    if (!arr.length) return;

    await runInsertionSort(arr);
}

async function runInsertionSort(inputArray) {
    const startBtn = document.querySelector(`button[onclick="startInsertionSort()"]`);
    const speedInput = document.getElementById('insertion-speed');
    const timerEl = document.getElementById('insertion-timer');
    const container = document.getElementById('insertion-container');

    if (startBtn) startBtn.disabled = true;
    if (speedInput) speedInput.disabled = true;

    const t0 = performance.now();
    timerEl.textContent = 'Time: 0 ms';
    const timerInterval = setInterval(() => {
        const dt = Math.round(performance.now() - t0);
        timerEl.textContent = `Time: ${dt} ms`;
    }, 50);

    let arr = [...inputArray];
    container.innerHTML = '';
    arr.forEach(val => {
        const bar = document.createElement('div');
        bar.className = 'bar';
        bar.style.height = `${val * 3}px`;
        const label = document.createElement('span');
        label.className = 'bar-label';
        label.textContent = val;
        bar.appendChild(label);
        container.appendChild(bar);
    });

    const bars = container.querySelectorAll('.bar');
    bars[0].classList.add('sorted');

    for (let i = 1; i < arr.length; i++) {
        bars[i].classList.add('min');
        const key = arr[i];
        let j = i - 1;

        const speed = Number(speedInput?.value) || 150;
        await sleep(Math.max(10, speed));

        while (j >= 0 && arr[j] > key) {
            bars[j].classList.add('highlight');
            bars[j + 1].classList.add('highlight');
            await sleep(Math.max(10, speed));

            arr[j + 1] = arr[j];
            bars[j + 1].style.height = `${arr[j + 1] * 3}px`;
            bars[j + 1].querySelector('.bar-label').textContent = arr[j + 1];

            bars[j].classList.remove('highlight');
            bars[j + 1].classList.remove('highlight');
            j--;
            await sleep(Math.max(10, speed));
        }

        arr[j + 1] = key;
        bars[j + 1].style.height = `${key * 3}px`;
        bars[j + 1].querySelector('.bar-label').textContent = key;
        bars[i].classList.remove('min');
        bars[j + 1].classList.add('sorted');
    }

    clearInterval(timerInterval);
    const totalMs = Math.round(performance.now() - t0);
    timerEl.textContent = `Time: ${totalMs} ms`;
    if (startBtn) startBtn.disabled = false;
    if (speedInput) speedInput.disabled = false;
}

// Quick Sort with Animation
async function runQuickSortAnimated() {
    if (quickSortData.length === 0) return;

    const animBtn = document.querySelector('button[onclick="runQuickSortAnimated()"]');
    const speedInput = document.getElementById('quick-speed');
    const timerEl = document.getElementById('quick-timer');
    const container = document.getElementById('quick-container');

    if (animBtn) animBtn.disabled = true;
    if (speedInput) speedInput.disabled = true;

    const t0 = performance.now();
    timerEl.textContent = 'Time: 0 ms';
    const timerInterval = setInterval(() => {
        const dt = Math.round(performance.now() - t0);
        timerEl.textContent = `Time: ${dt} ms`;
    }, 50);

    const arr = [...quickSortData];
    container.innerHTML = '';
    document.getElementById('quick-sort-output').style.display = 'block';

    // Create initial bars
    arr.forEach(val => {
        const bar = document.createElement('div');
        bar.className = 'bar';
        bar.style.height = `${val * 3}px`;
        const label = document.createElement('span');
        label.className = 'bar-label';
        label.textContent = val;
        bar.appendChild(label);
        container.appendChild(bar);
    });

    const speed = Number(speedInput?.value) || 200;

    // Quick sort with animation
    await quickSortWithAnimation(arr, 0, arr.length - 1, speed);

    // Mark all as sorted
    const bars = container.querySelectorAll('.bar');
    bars.forEach(bar => {
        bar.classList.remove('highlight');
        bar.classList.add('sorted');
    });

    clearInterval(timerInterval);
    const totalMs = Math.round(performance.now() - t0);
    timerEl.textContent = `Time: ${totalMs} ms`;
    if (animBtn) animBtn.disabled = false;
    if (speedInput) speedInput.disabled = false;
}

async function quickSortWithAnimation(arr, low, high, speed) {
    if (low < high) {
        const pi = await partition(arr, low, high, speed);
        await quickSortWithAnimation(arr, low, pi - 1, speed);
        await quickSortWithAnimation(arr, pi + 1, high, speed);
    } else if (low === high) {
        const bars = document.getElementById('quick-container').querySelectorAll('.bar');
        if (bars[low]) bars[low].classList.add('sorted');
    }
}

async function partition(arr, low, high, speed) {
    const bars = document.getElementById('quick-container').querySelectorAll('.bar');
    const pivot = arr[high];
    bars[high].classList.add('highlight');
    
    let i = low - 1;
    
    for (let j = low; j < high; j++) {
        bars[j].classList.add('min');
        await sleep(Math.max(10, speed));

        if (arr[j] < pivot) {
            i++;
            // Swap
            [arr[i], arr[j]] = [arr[j], arr[i]];
            
            bars[i].style.height = `${arr[i] * 3}px`;
            bars[j].style.height = `${arr[j] * 3}px`;
            bars[i].querySelector('.bar-label').textContent = arr[i];
            bars[j].querySelector('.bar-label').textContent = arr[j];
            
            await sleep(Math.max(10, speed / 2));
        }
        bars[j].classList.remove('min');
    }

    // Final swap
    [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
    bars[i + 1].style.height = `${arr[i + 1] * 3}px`;
    bars[high].style.height = `${arr[high] * 3}px`;
    bars[i + 1].querySelector('.bar-label').textContent = arr[i + 1];
    bars[high].querySelector('.bar-label').textContent = arr[high];
    bars[high].classList.remove('highlight');
    bars[i + 1].classList.add('sorted');

    await sleep(Math.max(10, speed));

    return i + 1;
}