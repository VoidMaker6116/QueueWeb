from collections import deque

class Graph:
    def __init__(self):
        self.graph = {}

    def add_station(self, station):
        if station not in self.graph:
            self.graph[station] = []

    def add_connection(self, station1, station2):
        self.graph[station1].append(station2)
        self.graph[station2].append(station1)

    def bfs_shortest_path(self, start, goal):
        # Return None early if either station doesn't exist
        if start not in self.graph or goal not in self.graph:
            return None

        # If start equals goal, return immediately
        if start == goal:
            return [start]

        queue = deque([[start]])
        visited = set()

        while queue:
            path = queue.popleft()
            node = path[-1]

            if node == goal:
                return path
            
            if node not in visited:
                visited.add(node)
                
                for neighbor in self.graph[node]:
                    new_path = list(path)
                    new_path.append(neighbor)
                    queue.append(new_path)

        return None
    
mrt_graph = Graph()

stations = [
    "North Ave", "Quezon Ave", "GMA Kamuning",
    "Cubao", "Santolan", "Ortigas",
    "Shaw Blvd", "Boni", "Guadalupe"
]

for station in stations:
    mrt_graph.add_station(station)

connections = [
    ("North Ave", "Quezon Ave"),
    ("Quezon Ave", "GMA Kamuning"),
    ("GMA Kamuning", "Cubao"),
    ("Cubao", "Santolan"),
    ("Santolan", "Ortigas"),
    ("Ortigas", "Shaw Blvd"),
    ("Shaw Blvd", "Boni"),
    ("Boni", "Guadalupe")
]

for s1, s2 in connections:
    mrt_graph.add_connection(s1, s2)
